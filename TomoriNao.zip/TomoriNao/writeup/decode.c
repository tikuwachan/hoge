int main(int argc, char *args[])
{
    char enc[] = "\x58\x35\x62\x35\x35\x7c\x3a\x67\x5d\x3a\x78\x3c\x7f\x3f\x6e\x7e\x72\x42\x00";
    int i = 0;
    for (i = 0; enc[i] != '\0'; i++) {
        enc[i] -= i + 1;
    }
    puts(enc);
    return 0;
}